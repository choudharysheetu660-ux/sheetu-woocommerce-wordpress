<footer class="footer">© <?php echo date('Y'); ?> Sheetu</footer>
<?php wp_footer(); ?>
</body></html>