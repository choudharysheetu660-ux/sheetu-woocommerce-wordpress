<?php get_header(); ?>
<h2>Welcome to My WooCommerce Store</h2>
<?php echo do_shortcode('[products limit="8"]'); ?>
<?php get_footer(); ?>