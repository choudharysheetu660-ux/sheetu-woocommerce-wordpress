<?php
function sheetu_wc_setup() {
    add_theme_support('woocommerce');
}
add_action('after_setup_theme', 'sheetu_wc_setup');

function sheetu_wc_assets() {
    wp_enqueue_style('sheetu-wc-css', get_template_directory_uri() . '/css/style.css');
    wp_enqueue_script('sheetu-wc-js', get_template_directory_uri() . '/js/script.js', array(), false, true);
}
add_action('wp_enqueue_scripts', 'sheetu_wc_assets');
?>